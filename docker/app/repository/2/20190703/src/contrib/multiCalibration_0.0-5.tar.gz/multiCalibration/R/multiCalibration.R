
#' Function to assess the calibration of multinomial probabilities (i.e. the reliability/accuracy of multinomial probabilities based on a GENERIC multiclass risk model).
#' @references "Van Hoorde, K. et al. Assessing calibration of multinomial risk prediction models. Statistics in Medicine 2014 Jul 10; 33 (15): 2585-96. doi: 10.1002/sim.6114."
#' @references "Van Hoorde, K. et al. A spline-based tool to assess and visualize the calibration of multiclass risk predictions. Journal of Biomedical Informatics 2015 Apr; 54: 283-293. doi: 10.1016/j.jbi.2014.12.016."
#' @param outcome column vector containing the outcome for every case, with values 1 to k (e.g. k=3)
#' @param k number of outcome categories (e.g. 3)
#' @param p matrix with the probabilities of the prediction model, ordered from prob(cat. 1) to prob(cat. k)
#' @param r reference category (default: category 1)
#' @param dfr degrees of freedom for the non-parametric/generic calibration (default: 2)
#' @param generic logical indicating whether the generic framework should be considered (default: TRUE)
#' @param plotseparate logical indicating whether separate (non-)parametric calibration plots are constructed (default: TRUE)
#' @param plotoverall logical indicating whether overall (non-)parametric calibration plots are constructed (default: TRUE)
#' @param datapoints logical indicating whether the individual datapoints are shown in the overall (non-)parametric calibration plots (default:  TRUE)
#' @param smoothing logical indicating whether a smoothed line (using cubic splines) is added to the calibration plots (default: TRUE)
#' @param smoothpar smoothing parameter for the smoothed line (default: 1)
#' @param eci logical indicating whether the estimated calibration index (ECI) should be computed (default:  TRUE)
#' @param legendOutcome for the different outcome categories (if not specified cat 1, cat 2, ... cat k)
#' @param pathGraphs location to save the graphs
#' @return calibration plots
#' @author Kirsten Van Hoorde
#' @import VGAM
#' @export
multiCalibrationGeneric <-
		function(outcome, k, p, r = 1, dfr = 2, generic = TRUE, plotseparate = TRUE, plotoverall = TRUE, datapoints = TRUE, 
				smoothing = TRUE, smoothpar = 1, eci = TRUE, legendOutcome = NULL, pathGraphs = "./"){
	
	pref <- p[,r]
	z <- log(p[,-r]/pref)

	#generic multiclass risk model, so no computation of estimates, no parametric framework, no intercepts and slopes and tests
	multiCalibration(outcome = outcome, k = k, p = p, LP = z, r = r, estimates = FALSE, dfr = dfr, parametric = FALSE, generic = TRUE, plotseparate = plotseparate, plotoverall = plotoverall,
			datapoints = datapoints, smoothing = smoothing, smoothpar = smoothpar, eci = eci, intercept = FALSE, slope = FALSE, test = FALSE, legendOutcome = legendOutcome, pathGraphs = pathGraphs)
	
}

#' Function to assess the calibration of multinomial probabilities (i.e. the reliability/accuracy of multinomial probabilities).
#' @references "Van Hoorde, K. et al Assessing calibration of multinomial risk prediction models. Statistics in Medicine 2014 Jul 10; 33 (15): 2585-96. doi: 10.1002/sim.6114."
#' @param outcome column vector containing the outcome for every case, with values 1 to k (e.g. k=3)
#' @param k number of outcome categories (e.g. 3)
#' @param p matrix with the probabilities of the prediction model, ordered from prob(cat. 1) to prob(cat. k)
#' @param LP matrix with all the linear predictors with respect to the chosen reference category, ordered (e.g. LP2vs1, LP3vs1, ..., LPkvs1)
#' @param r reference category (default: category 1)
#' @param estimates logical indicating whether the coefficients of the parametric recalibration framework are desired (default: FALSE)
#' @param dfr degrees of freedom for the non-parametric/generic calibration (default: 2)
#' @param parametric logical indicating whether the parametric framework should be considered (default: TRUE)
#' @param generic logical indicating whether the generic framework should be considered (default: TRUE)
#' @param plotseparate logical indicating whether separate (non-)parametric calibration plots are constructed (default: TRUE)
#' @param plotoverall logical indicating whether overall (non-)parametric calibration plots are constructed (default: TRUE)
#' @param datapoints logical indicating whether the individual datapoints are shown in the overall (non-)parametric calibration plots (default:  TRUE)
#' @param smoothing logical indicating whether a smoothed line (using cubic splines) is added to the calibration plots (default: TRUE)
#' @param smoothpar smoothing parameter for the smoothed line (default: 1)
#' @param eci logical indicating whether the estimated calibration index (ECI) should be computed (default:  TRUE)
#' @param intercept logical indicating whether calibration intercepts are desired (default: FALSE)
#' @param slope logical indicating whether calibration slopes are desired (default: FALSE)
#' @param test logical indicating whether statistical tests for calibration are desired (default: FALSE)
#' @param legendOutcome for the different outcome categories (if not specified cat 1, cat 2, ... cat k)
#' @param pathGraphs location to save the graphs
#' @return list with requested output (i.e. "ECI","Coefficients of parametric recalibration framework","Calibration Intercepts with 95\% CI","Calibration Slopes with 95\% CI","Deviances","P-values")
#' and calibration plots
#' @author Kirsten Van Hoorde
#' @import VGAM
#' @import bayesm
#' @examples
#' library(VGAMdata)
#' library(VGAM)
#' data(xs.nz)
#' marital.nz <- xs.nz[,c("marital","sex","age","height","weight")]
#' marital.nz <- marital.nz[complete.cases(marital.nz),]
#' fit.ms <- vglm(marital ~ sex + age + height + weight, 
#' 				multinomial(refLevel = 1), data = marital.nz)
#' predictions <- predict(fit.ms, newdata = marital.nz)
#' multiCalibration(outcome = as.numeric(marital.nz$marital), k = 4, 
#' 				p = fitted(fit.ms), LP = predictors(fit.ms), estimates = TRUE, 
#' 				intercept = TRUE, slope = TRUE, test = TRUE)
#' multiCalibration(outcome = as.numeric(marital.nz$marital), k = 4, 
#' 				LP = predictions, estimates = TRUE, intercept = TRUE, 
#' 				slope = TRUE, test = TRUE)
#' multiCalibration(outcome = as.numeric(marital.nz$marital), k = 4, 
#' 				LP = predictions, estimates = TRUE, intercept = TRUE, 
#' 				slope = TRUE, test = TRUE, 
#' 				legendOutcome = c("single", "married", "divorced", "widowed"))
#' @export
multiCalibration <-
function(outcome, k, p = NULL, LP, r = 1, estimates = FALSE, dfr = 2, parametric = TRUE, generic = TRUE, plotseparate = TRUE, plotoverall = TRUE, datapoints = TRUE, 
		smoothing = TRUE, smoothpar = 1, eci = TRUE, intercept = FALSE, slope = FALSE, test = FALSE, legendOutcome = NULL, pathGraphs = "./"){

# checks
	if(k != length(table(outcome))){stop(paste0('The number of categories in outcome (i.e. ', length(table(outcome)), 'does not equal the specified number of categories (i.e. ', k, ').'))}
	if(! all(outcome %in% 1:k)){stop(paste0('The column vector with outcome should contain values 1 to k (with k=', k,').'))}
	if(! r %in% 1:k){stop(paste0('The given reference category (', r, ') is not possible.'))}     
	if(isTRUE(plotoverall) && !isTRUE(datapoints) && !isTRUE(smoothing)){stop('For the overall (non-)parametric calibration plots either datapoints or smoothed lines should be requested.')}
	if(dim(LP)[2]!=k-1){stop(paste0('The number of columns in LP (i.e. ', dim(LP)[2],') does not equal the specified number of categories minus 1 (i.e. ', k-1, ').'))}
	if(!is.matrix(LP)){stop('LP is not a matrix.')}
	
# additional checks for p
	if(is.null(p)){
		if(r!=k){
			LPall <- cbind(LP[,1:r-1], 0, LP[,r:(k-1)])
		}else{
			LPall <- cbind(LP[,1:r-1], 0)
		}
		expLP <- exp(LPall)
		denominator <- rowSums(expLP)
		probabilities <- expLP / denominator
		p <- probabilities
	}
	if(dim(p)[2]!=k){stop(paste0('The number of columns in p (i.e. ', dim(p)[2],') does not equal the specified number of categories (i.e. ', k, ').'))}
	if(!is.matrix(p)){stop('p is not a matrix.')}
	
# if tests for perfect calibration are requested, automatically calibration intercepts and calibration slopes are given
	if(isTRUE(test) & any(!isTRUE(intercept),!isTRUE(slope))){
		warning(paste0("Tests for perfect calibration should only be used in combination with calibration intercepts and calibration slopes. ",
						"Therefore, the estimates of the calibration intercepts and slopes with their CI will be returned as well."))
		intercept <- slope <- TRUE
	}
	
# if no parametric model is fitted (either not requested or no 'original' linear predictors as input), calibration intercepts, calibration and slopes will not be computed or returned
	if(!isTRUE(parametric) && any(isTRUE(intercept), isTRUE(slope), isTRUE(test), isTRUE(estimates))){
		warning("No calibration intercepts, calibration slopes or tests will be returned since the parametric framework is not considered.")
		intercept <- slope <- test <- estimates <- FALSE
	}
	
# probabilities
	probs <- split(p,col(p))    
	
# linear predictors necessary for non-parametric calibration plot - give a name to each linear predictor 
# seperately
	lps <- split(LP,col(LP))
	for(i in 1:(k-1)){assign(paste("lp", i, sep = ""),unlist(lps[[i]]))}
	
	
	###############################################
# parametric logistic recalibration framework 
# cf. section 2.2.1.                          
	###############################################
	
# reference category r
# LP = matrix with linear predictors
	
	fitp<-vglm(outcome~LP,family=multinomial(refLevel=r))
	if(isTRUE(estimates)){est<-coefficients(fitp)
		names(est) <- paste('estimate',names(est),sep='.')}
	
	
	#######################################################
# non-parametric recalibration framework (using df=2) 
# cf. section 2.2.1.                                  
	#######################################################
	
# reference category r
# lpi = ith linear predictor
# for k outcome categories, there are k-1 linear predictors
	
	formulaNp <- as.formula(paste0("outcome~",paste0(sapply(1:(k-1), function(j) paste0("s(lp",j,",df=",dfr,")")),collapse="+")))
	fitnp<-vgam(formulaNp,family=multinomial(refLevel=r))
	
	
	###############################################                  
# Separate (non-)parametric calibration plots
	###############################################
	
# parametric calibration plots 
# cf. section 2.2.2.           
	################################
	
	if(isTRUE(parametric) & isTRUE(plotseparate)){
		pathSeparateParametric <- paste0(pathGraphs,"SeparateParametricCalibrationPlot.pdf")
		pdf(pathSeparateParametric, width = 7, height = 7)
		separateParametricCalibrationPlot(k = k, probs = probs, fitp = fitp, smoothing = smoothing, smoothpar = smoothpar, legendOutcome = legendOutcome)
		dev.off()
	}
	
# non-parametric calibration plot 
# cf. section 2.2.2.              
	###################################
	
	if(isTRUE(generic) & isTRUE(plotseparate)){
		pathSeparateGeneric <- paste0(pathGraphs,"SeparateGenericCalibrationPlot.pdf")
		pdf(pathSeparateGeneric, width = 7, height = 7)
		separateGenericCalibrationPlot(k = k, probs = probs, fitnp = fitnp, smoothing = smoothing, smoothpar = smoothpar, legendOutcome = legendOutcome)
		dev.off()
	}
	
	#############################################            
# Overall (non-)parametric calibration plot 
	#############################################
		
# parametric calibration plot 
# cf. section 2.2.2.          
		###############################
		
	if(isTRUE(parametric) & isTRUE(plotoverall)){
		pathOverallParametric <- paste0(pathGraphs,"OverallParametricCalibrationPlot.pdf")
		pdf(pathOverallParametric, width = 7, height = 7)
		overallParametricCalibrationPlot(k = k, probs = probs, fitp = fitp, datapoints = datapoints, smoothing = smoothing, smoothpar = smoothpar, legendOutcome = legendOutcome)
		dev.off()
	}
		
# non-parametric calibration plot 
# cf. section 2.2.2.              
		###################################
	
	if(isTRUE(generic) & isTRUE(plotoverall)){
		pathOverallGeneric <- paste0(pathGraphs,"OverallGenericCalibrationPlot.pdf")
		pdf(pathOverallGeneric, width = 7, height = 7)
		overallGenericCalibrationPlot(k = k, probs = probs, fitnp = fitnp, datapoints = datapoints, smoothing = smoothing, smoothpar = smoothpar, legendOutcome = legendOutcome)
		dev.off()
	}
	
	########################################
# estimated calibration index
	########################################	
	
	if(isTRUE(eci)){
		
		estCalIndex <- ECI(predictions = p, observations = fitted(fitnp))
	
	}
		
	########################################
# estimation of calibration intercepts 
# cf. section 2.2.3. and 2.2.4.        
	########################################
	
	if(isTRUE(intercept)){
		
		estCalInt <- estimationCalibrationIntercept(outcome = outcome, LP = LP, r = r)
		int <- estCalInt$intVGAM
		estint <- estCalInt$estimatesIntercept
		
	}
	
	
	####################################
# estimation of calibration slopes 
# cf. section 2.2.3. and 2.2.4.    
	####################################
	
	if(isTRUE(slope)){
		
		estCalSlopes <- estimationCalibrationSlope(outcome = outcome, k = k, LP = LP, r = r)
		slopes <- estCalSlopes$slopesVGAM
		estslopes <- estCalSlopes$estimatesSlopes
	
	}
	
	
	#################################
# calibration testing          
# cf. section 2.2.3. and 2.2.4. 
	#################################
	
# this code requires the bayesm library developed by Peter Rossi
	
	if(isTRUE(test)){
		
		calibrationTests <- calibrationTesting(outcome = outcome, k = k, LP = LP, interceptVGAM = int, slopesVGAM = slopes)
		deviances <- calibrationTests$deviances
		pvalues <- calibrationTests$pvalues
		poverall <- pvalues["pOverall"]
			
	}
	
	
# Printing of results
# The probabilities of calibration intercepts and slopes are only shown when the hypothesis of perfect calibration is rejected.
	
	results<-list(if(isTRUE(eci)){estCalIndex}else{'Not requested'},if(isTRUE(estimates)){est}else{'Not requested'},if(isTRUE(intercept)){estint}else{'Not requested'},if(isTRUE(slope)){estslopes}else{'Not requested'},if(isTRUE(test)){deviances}else{'Not requested'},if(isTRUE(test)){if(poverall<0.05){pvalues}else{poverall}}else{'Not requested'})
	names(results)<-c("ECI","coefficientsRecalibration","calibrationIntercepts","calibrationSlopes","Deviances","PValues")
	n <- 1:length(results)
	selection <- c(isTRUE(eci),isTRUE(estimates),isTRUE(intercept),isTRUE(slope),isTRUE(test),isTRUE(test))
	results[n[selection]]
	
}

#' Function to plot separate parametric calibration plots.
#' @param k number of outcome categories
#' @param probs list of probabilities
#' @param fitp observed probabilities fitted/obtained via the parametric logistic recalibration framework (vglm call)
#' @param smoothing indicates whether a smoothed line (using cubic splines) is added to the calibration plots (default: TRUE)
#' @param smoothpar smoothing parameter for the smoothed line (default: 1)
#' @param legendOutcome for the different outcome categories (if not specified cat 1, cat 2, ... cat k)
#' @param title main title of the calibration plot
#' @param lwd linewidth of smoothed line
#' @return parametric calibration plot for each outcome category separately
#' @author Kirsten Van Hoorde
#' @export
separateParametricCalibrationPlot <- function(k, probs, fitp, smoothing = TRUE, smoothpar = 1, legendOutcome = NULL, title = "Parametric calibration plot", lwd = 4){
	
	if(length(probs) != k){ stop("The number of lists in 'probs' does not equal the specified number of categories.")}
	
	par(mfrow=c(ceiling(k/2),2))
	
	for(i in 1:k){
		p <- unlist(probs[[i]])
		if(isTRUE(smoothing)){color<-'grey'}else{color<-1+i}
		matplot(p,fitted(fitp)[,i],type="p",pch=i,col=color,lwd=1,ylab="",xlab="",xlim=0:1,ylim=0:1)
		par(new=T)
		ref <- rbind(c(0,0),c(1,1))
		matplot(ref,ref,type="l",col=1,lwd=2,ylab="Observed proportion",xlab="Predicted probability",xlim=0:1,ylim=0:1)
		# smoother for calibration plots 
		##################################
		# a = smoothing parameter
		if(isTRUE(smoothing)){
			a = smoothpar
			points(smooth.spline(p, fitted(fitp)[,i],spar=a), type="l", col=(1+i), lwd = lwd)}
		# legend
		if(is.null(legendOutcome)){
			legend <- c(paste("cat ", i, sep = ""))
		}else{
			if(length(legendOutcome) != k) stop("The length of the specified legendOutcome does not match the number of outcome categories")
			legend <- legendOutcome[i]
		}
		legend("bottomright",col=(1+i),lty =1,legend=legend)
		title(main = title)
		par(new=F)
	}
	
}
		
#' Function to plot separate generic / non-parametric calibration plots.
#' @param k number of outcome categories
#' @param probs list of probabilities
#' @param fitnp observed probabilities fitted/obtained via the non-parametric or generic logistic recalibration framework (vgam call)
#' @param smoothing indicates whether a smoothed line (using cubic splines) is added to the calibration plots (default: TRUE)
#' @param smoothpar smoothing parameter for the smoothed line (default: 1)
#' @param legendOutcome for the different outcome categories (if not specified cat 1, cat 2, ... cat k)
#' @param title main title of the calibration plot
#' @param lwd linewidth of smoothed line
#' @return generic / non-parametric calibration plot for each outcome category separately
#' @author Kirsten Van Hoorde
#' @export
separateGenericCalibrationPlot <- function(k, probs, fitnp, smoothing = TRUE, smoothpar = 1, legendOutcome = NULL, title = "Generic calibration plot", lwd = 4){
	
	if(length(probs) != k){ stop("The number of lists in 'probs' does not equal the specified number of categories.")}
	
	par(mfrow=c(ceiling(k/2),2))
	
	for(i in 1:k){
		p <- unlist(probs[[i]])
		if(isTRUE(smoothing)){color<-'grey'}else{color<-1+i}
		matplot(p,fitted(fitnp)[,i],type="p",pch=i,col=color,lwd=1,ylab="",xlab="",xlim=0:1,ylim=0:1)
		par(new=T)
		ref <- rbind(c(0,0),c(1,1))
		matplot(ref,ref,type="l",col=1,lwd=2,ylab="Observed proportion",xlab="Predicted probability",xlim=0:1,ylim=0:1)
		# smoother for calibration plots 
		##################################
		# a = smoothing parameter
		if(isTRUE(smoothing)){
			a = smoothpar
			points(smooth.spline(p, fitted(fitnp)[,i],spar=a), type="l", col=(1+i), lwd = lwd)}
		# legend
		if(is.null(legendOutcome)){
			legend <- c(paste("cat ", i, sep = ""))
		}else{
			if(length(legendOutcome) != k) stop("The length of the specified legendOutcome does not match the number of outcome categories")
			legend <- legendOutcome[i]
		}
		legend("bottomright",col=(1+i),lty =1,legend=legend)
		title(main = title)
		par(new=F)
	}
	
}

#' Function to plot overall parametric calibration plots.
#' @param k number of outcome categories
#' @param probs list of probabilities
#' @param fitp observed probabilities fitted/obtained via the parametric logistic recalibration framework (vglm call)
#' @param datapoints indicates whether the individual datapoints are shown in the overall (non-)parametric calibration plots (default:  TRUE)
#' @param smoothing indicates whether a smoothed line (using cubic splines) is added to the calibration plots (default: TRUE)
#' @param smoothpar smoothing parameter for the smoothed line (default: 1)
#' @param legendOutcome for the different outcome categories (if not specified cat 1, cat 2, ... cat k)
#' @param title main title of the calibration plot
#' @param lwd linewidth of smoothed line
#' @return overall parametric calibration plot
#' @author Kirsten Van Hoorde
#' @export
overallParametricCalibrationPlot <- function(k, probs, fitp, datapoints = TRUE, smoothing = TRUE, smoothpar = 1, legendOutcome = NULL, title = "Parametric calibration plot", lwd = 4){
	
	if(length(probs) != k){ stop("The number of lists in 'probs' does not equal the specified number of categories.")}
	
	if(isTRUE(datapoints)){for(i in 1:k){p <- unlist(probs[[i]])
			matplot(p,fitted(fitp)[,i],type="p",pch=i,col=(1+i),lwd=1,ylab="",xlab="",xlim=0:1,ylim=0:1)
			par(new=T)}}
	ref <- rbind(c(0,0),c(1,1))
	matplot(ref,ref,type="l",col=1,lwd=2,ylab="Observed proportions",xlab="Predicted probabilities",xlim=0:1,ylim=0:1)
	# smoother for calibration plots 
	##################################
	# a = smoothing parameter
	if(isTRUE(smoothing)){
		a = smoothpar
		for(i in 1:k){p <- unlist(probs[[i]])
			points(smooth.spline(p, fitted(fitp)[,i],spar=a), type="l", col=(1+i), lwd = lwd)}}
	# legend
	if(is.null(legendOutcome)){
		legendOutcome <- sapply(1:k, function(i) paste("cat", i, sep=""))
	}else{
		if(length(legendOutcome) != k) stop("The length of the specified legendOutcome does not match the number of outcome categories")
	}
	legend("bottomright",col=2:(k+1),lty =1,legend=legendOutcome)
	title(main = title)
	par(new=F)
	
}

#' Function to plot separate generic / non-parametric calibration plots.
#' @param k number of outcome categories
#' @param probs list of probabilities
#' @param fitnp observed probabilities fitted/obtained via the non-parametric or generic logistic recalibration framework (vgam call)
#' @param datapoints indicates whether the individual datapoints are shown in the overall (non-)parametric calibration plots (default:  TRUE)
#' @param smoothing indicates whether a smoothed line (using cubic splines) is added to the calibration plots (default: TRUE)
#' @param smoothpar smoothing parameter for the smoothed line (default: 1)
#' @param legendOutcome for the different outcome categories (if not specified cat 1, cat 2, ... cat k)
#' @param title main title of the calibration plot
#' @param lwd linewidth of smoothed line
#' @return generic / non-parametric calibration plot for each outcome category separately
#' @author Kirsten Van Hoorde
#' @export
overallGenericCalibrationPlot <- function(k, probs, fitnp, datapoints = TRUE, smoothing = TRUE, smoothpar = 1, legendOutcome = NULL, title = "Generic calibration plot", lwd = 4){
	
	if(length(probs) != k){ stop("The number of lists in 'probs' does not equal the specified number of categories.")}
	
	if(isTRUE(datapoints)){for(i in 1:k){p <- unlist(probs[[i]])
			matplot(p,fitted(fitnp)[,i],type="p",pch=i,col=(1+i),lwd=1,ylab="",xlab="",xlim=0:1,ylim=0:1)
			par(new=T)}}
	ref <- rbind(c(0,0),c(1,1))
	matplot(ref,ref,type="l",col=1,lwd=2,ylab="Observed proportions",xlab="Predicted  probabilities",xlim=0:1,ylim=0:1)
	# smoother for calibration plots 
	##################################
	# a = smoothing parameter
	if(isTRUE(smoothing)){a = smoothpar
		for(i in 1:k){p <- unlist(probs[[i]])
			points(smooth.spline(p, fitted(fitnp)[,i],spar=a), type="l", col=(1+i), lwd = lwd)}}
	# legend
	if(is.null(legendOutcome)){
		legendOutcome <- sapply(1:k, function(i) paste("cat", i, sep=""))
	}else{
		if(length(legendOutcome) != k) stop("The length of the specified legendOutcome does not match the number of outcome categories")
	}
	legend("bottomright",col=2:(k+1),lty =1,legend=legendOutcome)
	title(main = title)
	par(new=F)
	
}

#' Quantification of the lack of calibration via the estimated calibration index (ECI) with theoretical range between 0 and 100.
#' @references "Van Hoorde, K. et al. A spline-based tool to assess and visualize the calibration of multiclass risk predictions. Journal of Biomedical Informatics 2015 Apr; 54: 283-293. doi: 10.1016/j.jbi.2014.12.016."
#' @param predictions matrix with predicted probabilities for k outcome categories (nSamples x k)
#' @param observations matrix with observed probabilities (not observed outcomes) for k outcome categories (nSamples x k; based on a generic multiclass risk model)
#' @return estimated calibration index (ECI)
#' @author Kirsten Van Hoorde
#' @export
ECI <- function(predictions, observations){
	if(!all(dim(predictions)==dim(observations))){
		stop("The dimensions of the predictions and observations matrix do not match.")
	}
	
	difference <- predictions - observations
	squaredDifference <- sum(difference*difference)
	averaging <- dim(predictions)[1]*dim(predictions)[2]
	
	averagedSquaredDifference <- squaredDifference/averaging
	
	scaling <- 100 * dim(predictions)[2]/2
	
	estimatedCalibrationIndex <- averagedSquaredDifference * scaling
	return(estimatedCalibrationIndex)
	
}
		
#' Estimation of calibration intercept with CI (default 95\% CI).
#' @param outcome column vector containing the outcome for every case, with values 1 to k 
#' @param LP matrix with all the linear predictors with respect to the chosen reference category, ordered (e.g. LP2vs1 and LP3vs1)
#' @param r reference category (default: category 1)
#' @param ciLevel desired confidence level (default: 0.95) 
#' @return vgam model and estimate of calibration intercept with (95\%) CI
#' @author Kirsten Van Hoorde
#' @import VGAM
#' @export
estimationCalibrationIntercept <- function(outcome, LP, r, ciLevel = 0.95){
	
	if(!is.matrix(LP)){stop('LP is not a matrix.')}
	
	nIntercept <- dim(LP)[2]
	int <- vgam(outcome~1,offset=LP,family=multinomial(refLevel=r))
	coeffint <- coefficients(int)
	se <- sqrt(diag(vcov(int)))
	alpha <- 1-ciLevel
	ciValue <- 1-alpha/2
	ciIntercept <- sapply(1:nIntercept, function(i)
				c(LL = coeffint[i] - qnorm(ciValue) * se[i], UL = coeffint[i] + qnorm(ciValue) * se[i]),
				simplify = FALSE)
	estIntercept <- unlist(sapply(1:nIntercept, function(i)
				c(coeffint[i],ciIntercept[[i]]), simplify = FALSE))
	namesIntercept <- paste('calInt', sapply(1:nIntercept, function(i) sapply(c('.','LL.','UL.'), function(j) paste(j,i, sep = ""))), sep = "")
	names(estIntercept) <- namesIntercept
	list("intVGAM" = int, "estimatesIntercept" = estIntercept)
	
}

#' Estimation of calibration slopes with CI (default 95\% CI).
#' @param outcome column vector containing the outcome for every case, with values 1 to k
#' @param k number of outcome categories 
#' @param LP matrix with all the linear predictors with respect to the chosen reference category, ordered (e.g. LP2vs1 and LP3vs1)
#' @param r reference category (default: category 1)
#' @param ciLevel desired confidence level (default: 0.95) 
#' @return vgam model and estimate of calibration intercept with (95\%) CI
#' @author Kirsten Van Hoorde
#' @import VGAM
#' @export
estimationCalibrationSlope <- function(outcome, k, LP, r, ciLevel = 0.95){
	
	if(k != length(table(outcome))){stop('The number of categories in outcome does not equal the specified number of categories.')}
	if(dim(LP)[2]!=k-1){stop('The number of columns in LP does not equal the specified number of categories minus 1.')}
	if(! r %in% 1:k){stop('The given reference category (r) is not possible.')}     
	if(!is.matrix(LP)){stop('LP is not a matrix.')}
	
	
	# linear predictors necessary for non-parametric calibration plot - give a name to each linear predictor 
	# seperately
	lps <- split(LP,col(LP))
	for(i in 1:(k-1)){assign(paste("lp", i, sep = ""),unlist(lps[[i]]))}
	
	interceptConstraint <-diag(k-1)
	clist <- sapply(1:k, function(j) if(j==1){
							diag(k-1)
						}else{
							interceptConstraint[,j-1,drop=FALSE]
						}, simplify = FALSE)
	names(clist) <- c("(Intercept)", sapply(1:(k-1), function(name) paste0("lp",name)))
	
	formula <- as.formula(paste0("outcome~",paste0(sapply(1:(k-1), function(j) paste0("lp",j)),collapse="+")))
	slopes<-vgam(formula,family=multinomial(refLevel=r),constraints=clist)
	coeffslopes<-coefficients(slopes)[k:length(coefficients(slopes))]
	nSlopes <- length(coeffslopes)
	se<-sqrt(diag(vcov(slopes)))
	alpha <- 1-ciLevel
	ciValue <- 1-alpha/2
	ciSlopes <- sapply(1:nSlopes, function(i)
				c(LL = coeffslopes[i] - qnorm(ciValue) * se[i], UL = coeffslopes[i] + qnorm(ciValue) * se[i]),
			simplify = FALSE)
	estSlopes <- unlist(sapply(1:nSlopes, function(i)
						c(coeffslopes[i],ciSlopes[[i]]), simplify = FALSE))
	namesSlopes <- paste('calSlope', sapply(1:nSlopes, function(i) sapply(c('.','LL.','UL.'), function(j) paste("Lp", j, i, sep = ""))), sep = "")
	names(estSlopes) <- namesSlopes
	list("slopesVGAM" = slopes, "estimatesSlopes" = estSlopes)
	
}

#' Function to test the calibration (i.e. overall - calibration intercepts - calibration slopes).
#' @param outcome column vector containing the outcome for every case, with values 1 to k 
#' @param k number of outcome categories 
#' @param LP matrix with all the linear predictors with respect to the chosen reference category, ordered (e.g. LP2vs1 and LP3vs1)
#' @param interceptVGAM vgam of estimation calibration intercepts
#' @param slopesVGAM vgam of estimation calibration slopes
#' @return list with deviances and p-values for overall calibration intercepts and calibration slopes
#' @author Kirsten Van Hoorde
#' @import bayesm
#' @export
calibrationTesting <- function(outcome, k, LP, interceptVGAM, slopesVGAM){
	
	if(k != length(table(outcome))){stop('The number of categories in outcome does not equal the specified number of categories.')}
	if(dim(LP)[2]!=k-1){stop('The number of columns in LP does not equal the specified number of categories minus 1.')}
	if(!is.matrix(LP)){stop('LP is not a matrix.')}
	
	# -2 log-likelihood of model without adaptations
	alpha <- rep(0,k-1)
	matrixBetas <-diag(k-1)
	parametersk <- c(alpha, sapply(1:(k-1), function(beta) as.vector(matrixBetas[,beta]))) # c(intercepts (all zero), coefficients for first equation, coefficients for second equation, ...) or e.g. c(alpha1,alpha2,b22,b23,b32,b33)
	Xdk=LP
	x <- createX(p=k,na=0,nd=k-1,Xa=NULL,Xd=Xdk,INT=TRUE,DIFF=FALSE,base=1)
	deviancewithout <- -2*llmnl(parametersk,outcome,x)
	names(deviancewithout)<-c('devianceOriginal')
	
	devint <- deviance(interceptVGAM)
	names(devint)<-c('devianceIntercept')
	devslopes <- deviance(slopesVGAM)
	names(devslopes)<-c('devianceSlopes')
	
	# overall calibration (i.e. calibration intercepts and slopes) 
	################################################################
	
	poverall<- pchisq(deviancewithout - devslopes, df = 2*(k-1), lower.tail = FALSE)
	
	# calibration intercepts 
	##########################
	
	pint<- pchisq(deviancewithout - devint, df = k-1, lower.tail = FALSE)
	
	# calibration slopes 
	######################
	
	pslopes<- pchisq(devint - devslopes, df = k-1, lower.tail = FALSE)
	names(poverall)<-c('pOverall')
	names(pint)<-c('pInt')
	names(pslopes)<-c('pSlopes')
	
	deviances <- c(deviancewithout, devint, devslopes)
	pvalues <- c(poverall, pint, pslopes)
	list("deviances" = deviances, "pvalues" = pvalues)
	
}
	
